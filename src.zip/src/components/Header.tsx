import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Menu,
  X,
  Sun,
  Moon,
  User,
  Briefcase,
  Code2,
  FolderGit2,
  Award,
  Mail,
  Github,
  Linkedin,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { navLinks, profileInfo } from '../constants';

const HEADER_OFFSET = 72;

const navIcons: Record<string, React.ElementType> = {
  about: User,
  experience: Briefcase,
  skills: Code2,
  projects: FolderGit2,
  certifications: Award,
  contact: Mail,
};

export const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('');
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const { theme, toggleTheme } = useTheme();

  /* ---------- scroll spy + progress bar ---------- */
  useEffect(() => {
    const handleScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 50);

      const max = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(max > 0 ? Math.min(100, (y / max) * 100) : 0);

      let current = '';
      for (const link of navLinks) {
        const el = document.getElementById(link.id);
        if (el && el.getBoundingClientRect().top <= HEADER_OFFSET + 40) {
          current = link.id;
        }
      }
      setActiveSection(current);
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
    };
  }, []);

  /* ---------- lock page scroll while drawer is open ---------- */
  useEffect(() => {
    if (!isOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = previous;
    };
  }, [isOpen]);

  /* ---------- close on Escape / when resized to desktop ---------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setIsOpen(false);
    const onResize = () => window.innerWidth >= 768 && setIsOpen(false);
    window.addEventListener('keydown', onKey);
    window.addEventListener('resize', onResize);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('resize', onResize);
    };
  }, []);

  const scrollToSection = useCallback((id: string) => {
    const el = document.getElementById(id);
    if (!el) return;
    const top = el.getBoundingClientRect().top + window.scrollY - HEADER_OFFSET + 1;
    window.scrollTo({ top, behavior: 'smooth' });
  }, []);

  const handleNavClick = (id: string) => {
    const wasOpen = isOpen;
    setIsOpen(false);
    // Wait for the drawer to close and the body scroll lock to be released,
    // otherwise mobile browsers ignore the scroll.
    window.setTimeout(() => scrollToSection(id), wasOpen ? 250 : 0);
  };

  const goTop = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-white/80 dark:bg-dark/80 backdrop-blur-xl shadow-lg'
            : 'bg-white/70 dark:bg-dark/70 backdrop-blur-md md:bg-transparent md:dark:bg-transparent md:backdrop-blur-none'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 py-3 md:py-4">
          <nav className="flex items-center justify-between">
            {/* Logo */}
            <motion.a
              href="#"
              onClick={goTop}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="font-display text-2xl font-bold gradient-text"
              aria-label="Back to top"
            >
              Y.
            </motion.a>

            {/* Desktop Navigation */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="hidden md:flex items-center gap-8"
            >
              {navLinks.map((link, index) => (
                <motion.button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative text-sm font-medium transition-colors ${
                    activeSection === link.id
                      ? 'text-primary-600 dark:text-primary-400'
                      : 'text-gray-600 dark:text-gray-400 hover:text-primary-500 dark:hover:text-primary-400'
                  }`}
                >
                  {link.title}
                  {activeSection === link.id && (
                    <motion.div
                      layoutId="activeSection"
                      className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-primary-500 to-accent-500 rounded-full"
                    />
                  )}
                </motion.button>
              ))}
            </motion.div>

            {/* Theme toggle & hamburger */}
            <div className="flex items-center gap-3">
              <button
                onClick={toggleTheme}
                className="p-2.5 rounded-full bg-gray-100 dark:bg-dark-card hover:bg-gray-200 dark:hover:bg-dark-surface transition-colors"
                aria-label="Toggle theme"
              >
                {theme === 'dark' ? (
                  <Sun size={20} className="text-yellow-500" />
                ) : (
                  <Moon size={20} className="text-primary-600" />
                )}
              </button>

              <button
                onClick={() => setIsOpen(true)}
                className="md:hidden p-2.5 rounded-full bg-gray-100 dark:bg-dark-card text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-dark-surface transition-colors"
                aria-label="Open menu"
                aria-expanded={isOpen}
                aria-controls="mobile-drawer"
              >
                <Menu size={20} />
              </button>
            </div>
          </nav>
        </div>

        {/* Scroll progress */}
        <div
          className="absolute bottom-0 left-0 h-[2px] bg-gradient-to-r from-primary-500 to-accent-500"
          style={{ width: `${progress}%` }}
        />
      </header>

      {/* Mobile drawer — rendered outside <header> so the header's
          backdrop-filter can't clip or trap this fixed layer. */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              key="overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              onClick={() => setIsOpen(false)}
              className="md:hidden fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm"
              aria-hidden="true"
            />

            <motion.aside
              key="drawer"
              id="mobile-drawer"
              role="dialog"
              aria-modal="true"
              aria-label="Site navigation"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.25, ease: 'easeOut' }}
              className="md:hidden fixed top-0 right-0 bottom-0 z-[70] w-[82%] max-w-sm flex flex-col bg-white dark:bg-dark-surface border-l border-gray-200 dark:border-dark-border shadow-2xl"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-dark-border">
                <span className="font-display text-xl font-bold gradient-text">
                  Menu
                </span>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2.5 rounded-full bg-gray-100 dark:bg-dark-card text-gray-700 dark:text-gray-200"
                  aria-label="Close menu"
                >
                  <X size={20} />
                </button>
              </div>

              <nav className="flex-1 overflow-y-auto px-4 py-4 space-y-1">
                {navLinks.map((link, index) => {
                  const Icon = navIcons[link.id] ?? User;
                  const active = activeSection === link.id;
                  return (
                    <motion.button
                      key={link.id}
                      onClick={() => handleNavClick(link.id)}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 + index * 0.04 }}
                      className={`flex items-center gap-4 w-full text-left px-4 py-3.5 rounded-xl text-base font-medium transition-colors ${
                        active
                          ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400'
                          : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-card'
                      }`}
                    >
                      <Icon size={20} />
                      {link.title}
                    </motion.button>
                  );
                })}
              </nav>

              <div className="flex items-center justify-between px-6 py-4 border-t border-gray-200 dark:border-dark-border">
                <div className="flex gap-3">
                  <a
                    href={profileInfo.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="LinkedIn"
                    className="w-10 h-10 rounded-full bg-gray-100 dark:bg-dark-card flex items-center justify-center text-primary-600 dark:text-primary-400"
                  >
                    <Linkedin size={18} />
                  </a>
                  <a
                    href={profileInfo.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="GitHub"
                    className="w-10 h-10 rounded-full bg-gray-100 dark:bg-dark-card flex items-center justify-center text-primary-600 dark:text-primary-400"
                  >
                    <Github size={18} />
                  </a>
                </div>
                <button
                  onClick={toggleTheme}
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 dark:bg-dark-card text-sm text-gray-700 dark:text-gray-300"
                >
                  {theme === 'dark' ? (
                    <Sun size={16} className="text-yellow-500" />
                  ) : (
                    <Moon size={16} className="text-primary-600" />
                  )}
                  {theme === 'dark' ? 'Light' : 'Dark'}
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
};
